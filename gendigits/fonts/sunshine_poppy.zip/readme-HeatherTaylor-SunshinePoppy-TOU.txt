In a nutshell:

-Attribution: Sunshine Poppy font by Heather T. (or Heather Taylor).
-License: This is a free font. Feel free to use it for personal or commercial projects. However, this font MAY NOT BE SOLD in any compilation or on its own, and it must be accompanied by this TOU.
-You may recolor, resize, or adjust any of the elements to your liking as long as it's for personal use, and is not used in a way that may be construed as harmful or prejudicial.
-Copyright and intellectual property relating to the font belong to Heather Taylor.
-Please contact me at hlmtaylor@gmail.com should you have any questions or futher inquiries, and please look for more of my STUFF at http://oohlalaartsy.blogspot.com/ !
-Enjoy!




